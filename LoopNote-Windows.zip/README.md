# LoopNote

LoopNote je malá desktopová webová aplikace pro Windows. Dvakrát klikni na `Spustit LoopNote.bat`, který ji otevře v aktuálním výchozím prohlížeči, nebo otevři `index.html` v Microsoft Edge či Google Chrome. Není potřeba instalovat žádné balíčky.

## Stránka ke stažení

`download.html` je jednoduchá stránka určená ke zveřejnění na webu. Nahraj ji na hosting společně se souborem `LoopNote-Windows.zip`; tlačítko na stránce pak stáhne připravenou aplikaci. Samotná stránka nehostuje nahrávky ani projekty.

## Co umí

- mít lobby s oddíly **Tvoření beatů**, **Lyrics** a **Records**,
- skládat rytmus ve 16krokovém sekvenceru (kopák, snare, hi-hat, clap a tom drum),
- přehrávat beat a měnit tempo,
- vytvořit náhodnou remixovanou variantu a vrátit poslední remix,
- psát poznámky i lyrics k projektu; projekty se průběžně ukládají v tomto prohlížeči,
- nahrát mikrofon přes přehrávaný beat; záznam hlasu se uloží spolu s textem lyrics a dá se přehrát nebo stáhnout z **Records**,
- stáhnout projekt jako JSON a znovu ho otevřít,
- exportovat čtyři takty jako WAV.

Při prvním nahrávání povol aplikaci přístup k mikrofonu. Nahrávky se ukládají do úložiště konkrétního prohlížeče. Pro zálohování nebo přenos beatů mezi počítači použij **Uložit projekt**.
